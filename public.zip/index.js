const path = require('path');
const express = require('express');
const app = express();
const SocketIO = require('socket.io');

// Ruta para servir "login.html" en la raíz
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// Configuración de la carpeta "public" como directorio de archivos estáticos
app.use(express.static(path.join(__dirname, 'public')));

// Establecer el puerto del servidor
app.set('port', process.env.PORT || 3000);

// Iniciar el servidor
const server = app.listen(app.get('port'), () => {
    console.log('Server port:', app.get('port'));
});

// Configuración de Socket.IO
const io = SocketIO(server);

// Función para generar un color aleatorio
function getRandomColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

const users = {};

io.on('connection', (socket) => {
    let username = '';
    let userColor = '';

    socket.on('join', (data) => {
        username = data.username;
        userColor = getRandomColor();
        users[username] = userColor;
        console.log(`${username} joined the chat with color ${userColor}`);
    });

    socket.on('message', (data) => {
        const userColor = users[data.username];
        socket.broadcast.emit('message', { username: data.username, msg: data.msg, color: userColor });
    });

    socket.on('disconnect', () => {
        delete users[username];
        console.log(`${username} left the chat`);
    });
});
